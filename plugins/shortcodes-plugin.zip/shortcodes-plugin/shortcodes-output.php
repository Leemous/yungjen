<?php 
	/*-----------------------------------------------------------------------------------*/
	/*
	/*  Define Shortcodes
	/*
	/*-----------------------------------------------------------------------------------*/	

	/*-- Columns ------------------------------------------------------------------------*/	
	/* 1/2 Column */
	function milk_one_half_col_func( $atts, $content = null ) {
	   return '<div class="col-md-6 col-sm-6"><p>' . do_shortcode($content) . '</p></div>';
	}
	add_shortcode( 'one_half_col', 'milk_one_half_col_func' );

	/* 1/3 Column */
	function milk_one_third_col_func( $atts, $content = null ) {
	   return '<div class="col-md-4 col-sm-6"><p>' . do_shortcode($content) . '</p></div>';
	}
	add_shortcode( 'one_third_col', 'milk_one_third_col_func' );

	/* 2/3 Column */
	function milk_two_third_col_func( $atts, $content = null ) {
	   return '<div class="col-md-8 col-sm-6"><p>' . do_shortcode($content) . '</p></div>';
	}
	add_shortcode( 'two_third_col', 'milk_two_third_col_func' );

	/* 1/4 Column */
	function milk_one_fourth_col_func( $atts, $content = null ) {
	   return '<div class="col-md-3 col-sm-6"><p>' . do_shortcode($content) . '</p></div>';
	}
	add_shortcode( 'one_fourth_col', 'milk_one_fourth_col_func' );

	/* 3/4 Column */
	function milk_three_fourth_col_func( $atts, $content = null ) {
	   return '<div class="col-md-9 col-sm-6"><p>' . do_shortcode($content) . '</p></div>';
	}
	add_shortcode( 'three_fourth_col', 'milk_three_fourth_col_func' );

	/* 1/2 Column Last */
	function milk_one_half_col_last_func( $atts, $content = null ) {
	   return '<div class="col-md-6 col-sm-6"><p>' . do_shortcode($content) . '</p></div></div><div class="row">';
	}
	add_shortcode( 'one_half_col_last', 'milk_one_half_col_last_func' );

	/* 1/3 Column Last */
	function milk_one_third_col_last_func( $atts, $content = null ) {
	   return '<div class="col-md-4 col-sm-6"><p>' . do_shortcode($content) . '</p></div></div><div class="row">';
	}
	add_shortcode( 'one_third_col_last', 'milk_one_third_col_last_func' );

	/* 2/3 Column Last */
	function milk_two_third_col_last_func( $atts, $content = null ) {
	   return '<div class="col-md-8 col-sm-6"><p>' . do_shortcode($content) . '</p></div></div><div class="row">';
	}
	add_shortcode( 'two_third_col_last', 'milk_two_third_col_last_func' );

	/* 1/4 Column Last */
	function milk_one_fourth_col_last_func( $atts, $content = null ) {
	   return '<div class="col-md-3 col-sm-6"><p>' . do_shortcode($content) . '</p></div></div><div class="row">';
	}
	add_shortcode( 'one_fourth_col_last', 'milk_one_fourth_col_last_func' );

	/* 3/4 Column Last */
	function milk_three_fourth_col_last_func( $atts, $content = null ) {
	   return '<div class="col-md-9 col-sm-6"><p>' . do_shortcode($content) . '</p></div></div><div class="row">';
	}
	add_shortcode( 'three_fourth_col_last', 'milk_three_fourth_col_last_func' );

	/*-- Alerts ------------------------------------------------------------------------*/	

	function milk_alert_success_func( $atts, $content = null ) {
	   return '<div class="alert alert-success">' . do_shortcode($content) . '</div>';
	}
	add_shortcode( 'alert_success', 'milk_alert_success_func' );

	function milk_alert_info_func( $atts, $content = null ) {
	   return '<div class="alert alert-info">' . do_shortcode($content) . '</div>';
	}
	add_shortcode( 'alert_info', 'milk_alert_info_func' );

	function milk_alert_warning_func( $atts, $content = null ) {
	   return '<div class="alert alert-warning">' . do_shortcode($content) . '</div>';
	}
	add_shortcode( 'alert_warning', 'milk_alert_warning_func' );

	function milk_alert_danger_func( $atts, $content = null ) {
	   return '<div class="alert alert-danger">' . do_shortcode($content) . '</div>';
	}
	add_shortcode( 'alert_danger', 'milk_alert_danger_func' );

	function milk_alert_success_dismiss_func( $atts, $content = null ) {
	   return '<div class="alert alert-success alert-dismissable">'
	   			. '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' 
	   			. do_shortcode($content) 
	   			. '</div>';
	}
	add_shortcode( 'alert_success_dismiss', 'milk_alert_success_dismiss_func' );

	function milk_alert_info_dismiss_func( $atts, $content = null ) {
	   return '<div class="alert alert-info alert-dismissable">' 
	   			. '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'
	   			. do_shortcode($content) 
	   			. '</div>';
	}
	add_shortcode( 'alert_info_dismiss', 'milk_alert_info_dismiss_func' );

	function milk_alert_warning_dismiss_func( $atts, $content = null ) {
	   return '<div class="alert alert-warning alert-dismissable">' 
	   			. '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'
	   			. do_shortcode($content) 
	   			. '</div>';
	}
	add_shortcode( 'alert_warning_dismiss', 'milk_alert_warning_dismiss_func' );

	function milk_alert_danger_dismiss_func( $atts, $content = null ) {
	   return '<div class="alert alert-danger alert-dismissable">' 
	   			. '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'
	   			. do_shortcode($content) 
	   			. '</div>';
	}
	add_shortcode( 'alert_danger_dismiss', 'milk_alert_danger_dismiss_func' );

	/*-- Toogles ------------------------------------------------------------------------*/	

	function milk_accordion_func( $atts, $content = null ) {
	   return '<div class="panel-group" id="accordion">' . do_shortcode($content) . '</div>';
	}
	add_shortcode( 'accordion', 'milk_accordion_func' );

	function milk_panel_func( $atts, $content = null ) {

		extract(shortcode_atts(array(
			'num' => '1',
			'title' => 'Title'
	    ), $atts));

	   return '<div class="panel panel-default">'
					. '<div class="panel-heading">'
						. '<h4 class="panel-title">'
							. '<a data-toggle="collapse" data-parent="#accordion" href="#collapse' . $num . '"class = "collapsed">'
								. $title	          		
							. '</a>'
						. '</h4>'
					. '</div>'
					. '<div id="collapse' . $num . '" class="panel-collapse collapse">'
						. '<div class="panel-body">'
							. do_shortcode($content)
						. '</div>'
					. '</div>'
				.'</div>';
	}
	add_shortcode( 'panel', 'milk_panel_func' );

	/*-- Tabs ------------------------------------------------------------------------*/	

	function milk_tab_headers_func( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'num' => ''
	    ), $atts));

	    STATIC $i = 0;
		$i++;

		preg_match_all( '/tab_content title="([^\"]+)"/i', $content, $matches, PREG_OFFSET_CAPTURE );
		
		$tab_titles = array();
		if( isset($matches[1]) ){ $tab_titles = $matches[1]; }

		$output = '';
		if( count($tab_titles) ){

			$output .= '<ul class="nav nav-tabs list-inline">';

			foreach ($tab_titles as $tab) {
				$output .= '<li><a href="#' . sanitize_title($tab[0]) . '" data-toggle="tab">' . $tab[0] . '</a></li>';
			}
			$output .= '</ul><div class="tab-content">';
			$output .= do_shortcode( $content );
			$output .= '</div>';
		} else {
			$output .= do_shortcode( $content );
		}

	   	return $output;
	}
	add_shortcode( 'tab_headers', 'milk_tab_headers_func' );


	function milk_tab_content_func( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'title' => 'tab'
	    ), $atts));
	   	return '<div class="tab-pane" id="' . sanitize_title($title) . '">' . do_shortcode($content) . '</div>';
	}
	add_shortcode( 'tab_content', 'milk_tab_content_func' );
	
	/*-- Buttons ------------------------------------------------------------------------*/	

	function milk_button_func( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'title' => 'Button',
			'url' => 'http://',
			'color' => 'default',
			'size' => ''
	    ), $atts));
	   	return '<a target="blanc" href="'. $url .'" type="button" class="btn btn-' . $color . ' ' . $size . '">'. $title .'</a>';
	}
	add_shortcode( 'button', 'milk_button_func' );

	/*-- Code ------------------------------------------------------------------------*/	

	function milk_code_func( $atts, $content = null ) {
		$output = str_replace('<br />',' ',$content);
	   	return '<pre><code>' . $output . '</code></pre>';
	}
	add_shortcode( 'code', 'milk_code_func' );

?>