(function() {

    tinymce.PluginManager.add('shortcodes', function( editor )
    {

        var columnSizes = ['1/2','1/3','1/4','2/3','3/4'];

        editor.addButton('shortcodes', {
            text: 'Shortcodes',
            icon: 'icon dashicons-art',
            type: 'menubutton',
            menu: [
            /*-----------------------------------------------------------------------------------*/
            /*
            /*  Columns
            /*
            /*-----------------------------------------------------------------------------------*/             
            {
            text: 'Columns',
                onclick: function() {
                    editor.windowManager.open( {
                        title: 'Insert Column',
                        body: [
                            {
                                type: 'listbox',
                                name: 'column_size',
                                label: 'Column Size',
                                'values': [
                                    {text: '1/2', value: 'one_half'},
                                    {text: '1/3', value: 'one_third'},
                                    {text: '2/3', value: 'two_third'},
                                    {text: '1/4', value: 'one_fourth'},
                                    {text: '3/4', value: 'three_fourth'}
                                ]
                            },
                            {
                                type: 'checkbox',
                                name: 'column_last',
                                label: 'Last column in the row?',
                            }
                        ],
                        onsubmit: function( e ) {
                            var last = String(e.data.column_last);
                            if( last === 'true' ) {
                                editor.insertContent( '[' + e.data.column_size + '_col_last]column content goes here[/' + e.data.column_size + '_col_last]');
                            } else {
                                editor.insertContent( '[' + e.data.column_size + '_col]column content goes here[/' + e.data.column_size + '_col]');
                            }
                        }
                    });
                }
            },
            /*-----------------------------------------------------------------------------------*/
            /*
            /*  Alerts
            /*
            /*-----------------------------------------------------------------------------------*/             
            {
            text: 'Alerts',
                onclick: function() {
                    editor.windowManager.open( {
                        title: 'Insert Alert',
                        body: [
                            {
                                type: 'listbox',
                                name: 'alert_type',
                                label: 'Alert Type',
                                'values': [
                                    {text: 'Success - Green', value: 'success'},
                                    {text: 'Info - Blue', value: 'info'},
                                    {text: 'Warning - Yellow', value: 'warning'},
                                    {text: 'Danger - Red', value: 'danger'}
                                ]
                            },
                            {
                                type: 'checkbox',
                                name: 'dismiss',
                                label: 'Should it be dismissable?',
                            }
                        ],
                        onsubmit: function( e ) {
                            var dismiss = String(e.data.dismiss);
                            if( dismiss === 'true' ) {
                                editor.insertContent( '[alert_' + e.data.alert_type + '_dismiss] Alert text goes here [/alert_' + e.data.alert_type + '_dismiss]');
                            } else {
                                editor.insertContent( '[alert_' + e.data.alert_type + '] Alert text goes here [/alert_' + e.data.alert_type + ']');
                            }
                        }
                    });
                }
            },
            /*-----------------------------------------------------------------------------------*/
            /*
            /*  Toggles
            /*
            /*-----------------------------------------------------------------------------------*/             
            {
            text: 'Toggles',
                onclick: function() {
                    editor.windowManager.open( {
                        title: 'Insert Toggle',
                        body: [
                            {
                                type: 'textbox',
                                name: 'toggles_num',
                                label: 'Number of Toggles',
                                value: ''
                            }
                        ],
                        onsubmit: function( e ) {
                            var num = String(e.data.toggles_num);
                            editor.insertContent( '[accordion]');
                            for ( var i = 1; i <= num; i++ ) {
                                editor.insertContent( '[panel num = "' + i + '" title="Tilte ' + i + '"] Toggle content goes here [/panel]');
                            }
                            editor.insertContent( '[/accordion]');
                        }
                    });
                }
            },
            /*-----------------------------------------------------------------------------------*/
            /*
            /*  Tabs
            /*
            /*-----------------------------------------------------------------------------------*/             
            {
            text: 'Tabs',
                onclick: function() {
                    editor.windowManager.open( {
                        title: 'Insert Tabs',
                        body: [
                            {
                                type: 'textbox',
                                name: 'tabs_num',
                                label: 'Number of Tabs',
                                value: ''
                            }
                        ],
                        onsubmit: function( e ) {
                            var num = String(e.data.tabs_num);
                            editor.insertContent( '[tab_headers num="' + num + '"]');
                            for ( var i = 1; i <= num; i++ ) {
                                editor.insertContent( '[tab_content title="Tab ' + i + '"] Tab ' + i + ' content goes here [/tab_content]');
                            }
                            editor.insertContent( '[/tab_headers]');
                        }
                    });
                }
            },
            /*-----------------------------------------------------------------------------------*/
            /*
            /*  Buttons
            /*
            /*-----------------------------------------------------------------------------------*/             
            {
            text: 'Buttons',
                onclick: function() {
                    editor.windowManager.open( {
                        title: 'Insert Button',
                        body: [
                            {
                                type: 'textbox',
                                name: 'title',
                                label: 'Button Title',
                                value: ''
                            },
                            {
                                type: 'textbox',
                                name: 'url',
                                label: 'Button URL',
                                value: ''
                            },
                            {
                                type: 'listbox',
                                name: 'color',
                                label: 'Button Color',
                                'values': [
                                    {text: 'Default', value: 'default'},
                                    {text: 'Violet', value: 'primary'},
                                    {text: 'Green', value: 'success'},
                                    {text: 'Beige', value: 'info'},
                                    {text: 'Yellow', value: 'warning'},
                                    {text: 'Red', value: 'danger'}
                                ]
                            },
                            {
                                type: 'listbox',
                                name: 'size',
                                label: 'Button Size',
                                'values': [
                                    {text: 'Extra Small', value: 'btn-xs'},
                                    {text: 'Small', value: 'btn-sm'},
                                    {text: 'Default', value: ''},
                                    {text: 'Large', value: 'btn-lg'}
                                ]
                            },
                        ],
                        onsubmit: function( e ) {
                            var title = String(e.data.title);
                            var url = String(e.data.url);
                            var color = String(e.data.color);
                            var size = String(e.data.size);
                            editor.insertContent( '[button title="'+ title +'" url="'+ url +'" color="'+ color +'" size="'+ size +'"/]');
                        }
                    });
                }
            },
            /*-----------------------------------------------------------------------------------*/
            /*
            /*  Code
            /*
            /*-----------------------------------------------------------------------------------*/             
            {
            text: 'Code',
                onclick: function() {
                    editor.insertContent( '[code] Your code goes here [/code]');
                }
            }

            ]
        });
    });
})();