<?php

/*
Plugin Name: Shortcode TinyMCE Plugin
Description: A WordPress plugin that will add a button to the tinyMCE editor to add shortcodes
Author: Pryanik
Version: 1.0
License: GPL2
*/


if ( ! class_exists( 'Milk_Shortcodes' ) ) :

class Milk_Shortcodes {

    function __construct() {

    	// get shortcodes-output.php
    	require_once( plugin_dir_path( __FILE__ ) .'shortcodes-output.php' );

    	// define paths
    	define('SHORTCODES_URI', plugin_dir_url( __FILE__ ) );
		define('SHORTCODES_DIR', plugin_dir_path( __FILE__ ) );

		// register
        add_action('init', array(&$this, 'init'));
        add_action('admin_init', array(&$this, 'admin_init'));
       	add_action('admin_enqueue_scripts', array(&$this, 'print_shortcode_scripts'));

	}
	

	/*--------------------------------------------------------------------*/
	/*
	/*	Register
	/*
	/*--------------------------------------------------------------------*/

	function init() {
		
		// exit conditions
		if ( ! current_user_can('edit_posts') && ! current_user_can('edit_pages') ) { return; }

		// editor condtions
		if ( get_user_option('rich_editing') == 'true' ) {

			add_filter( 'mce_external_plugins', array(&$this, 'add_rich_plugins') );

			add_filter( 'mce_buttons', array(&$this, 'register_rich_buttons') );

		}

	}

	/*--------------------------------------------------------------------*/
	/*
	/*	Print shortcode scripts in footer only if needed
	/*
	/*--------------------------------------------------------------------*/

	function print_shortcode_scripts() {

		// only print if shortcode is in use
		global $add_shortcode_scripts;
		if ( ! $add_shortcode_scripts ) {

			return;

		} else {
			wp_enqueue_scripts('shortcodes-css');
			wp_enqueue_scripts('shortcodes-js');

		}

	}

	/*--------------------------------------------------------------------*/
	/*
	/*	Add TinyMCE rich editor buttons
	/*
	/*--------------------------------------------------------------------*/

	function add_rich_plugins( $plugin_array ) {

		$plugin_array['shortcodes'] = SHORTCODES_URI . 'js/tinymce.js';

		return $plugin_array;

	}

	/*--------------------------------------------------------------------*/
	/*
	/*	Register TinyMCE rich editor buttons
	/*
	/*--------------------------------------------------------------------*/	

	function register_rich_buttons( $buttons ) {

		array_push( $buttons, 'shortcodes' );

		return $buttons;

	}

	/*--------------------------------------------------------------------*/
	/*
	/*	Enqueue Admin Scripts and Styles
	/*
	/*--------------------------------------------------------------------*/

	function admin_init() {

		// css
		wp_enqueue_style( 'tinymce-css', SHORTCODES_URI . 'css/style.css', true, '1.0', 'all' );

	}
    
}

$shortcodes = new Milk_Shortcodes();

endif;

?>